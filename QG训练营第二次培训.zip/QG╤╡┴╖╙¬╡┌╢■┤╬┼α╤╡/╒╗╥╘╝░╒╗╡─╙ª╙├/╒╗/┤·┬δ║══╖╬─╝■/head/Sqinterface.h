#ifndef __SQINTERFACE_H__
#define __SQINTERFACE_H__

#include "Sqstackmain.h"

//���溯��
void interface();

#endif 
